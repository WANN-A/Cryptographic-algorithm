#include <iostream>
#include "MD5.h"
using namespace std;


void printMD5(const string& message)
{
	cout << "MD5��"<< MD5(message).toStr() << endl;
}

int main() 
{
	string m;
	cout << "��Ϣ��";
	cin >> m;
	printMD5(m);
	
	system("pause");
	return 0;
}