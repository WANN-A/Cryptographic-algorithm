#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <iostream>
using namespace std;

int pow_mod(int a, int b, int p)//��ģ����  (a^b)% p
{
    int ans = 1;
    int tmp = a % p;
    while (b)
    {
        if (b & 1)
            ans = ans * tmp % p;
        b = b>> 1;
        tmp = tmp * tmp % p;
    }
    
    return ans % p;
   
}

void elgamal_en(int m, int pub, int p, int g, int* c1, int* c2)
{
    int k = 5;
    *c1 = pow_mod(g, k, p);
    *c2 = m * pow_mod(pub, k, p) % p;
}

int elgamal_de(int c1, int c2, int pri, int p, int g)
{
    
    int m;
    int c1_ = pow_mod(c1, p - 2, p);
    m = (c2 * pow_mod(c1_, pri, p) )% p;
  
    return m;
}

int is_prime(int p) 
{
    int i;
    for (i = 2; i <= sqrt(p); i++) 
    {
        if (p % i == 0)
            return 0;
    }
    return 1;
}

void main()
{
    int p;//����
    int g = 2;

    do {
        printf("������һ������:");
        scanf("%d", &p);
    } while (!is_prime(p));

    printf("�����û�A��˽Կ:");
    int pri;
    scanf("%d", &pri);

    int pub;
    pub = pow_mod(g, pri, p);

    printf("�û�A�Ĺ�ԿΪ:%d\n", pub);

    printf("��������(С��%d):", p);
    int m;
    scanf("%d", &m);

    int c1, c2;
    elgamal_en(m, pub, p, g, &c1, &c2);
    printf("�ù�Կ���ܺ������Ϊ:c1=%d,c2=%d\n", c1, c2);


    int m_ = elgamal_de(c1, c2, pri, p, g);
    printf("��˽Կ���ܺ������Ϊ:%d\n", m_);
}
//O(n^(1/2))